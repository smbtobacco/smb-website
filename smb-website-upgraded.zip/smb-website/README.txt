SMB GROUP WEBSITE — PT SALIM MAJU BERSAMA

Cara pakai:
1. Buka index.html di browser untuk preview.
2. Semua foto ada di folder assets.
3. Untuk online gratis, upload folder ini ke GitHub Pages, Netlify, atau Cloudflare Pages.
4. Jika memakai GitHub Pages: buat repository baru, upload seluruh isi folder, lalu Settings > Pages > Deploy from branch > main / root.

Catatan konten:
- Website mempertahankan tagline “Maju Bersama dengan SMB”.
- Core Value: BERSAMA — Berintegritas, Energik, Rukun, Sinergi, Aktif, Maju, Amanah.
- Konten distribusi memakai data yang telah diberikan sebelumnya dan dapat disesuaikan kembali dengan data operasional terbaru.
